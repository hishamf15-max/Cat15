package local.rahal.launcher;

import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

/** Network helper. Invoke only off the UI thread. No account or API key. */
final class OnlineData {
    static JSONObject get(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent","RahalLauncher/0.2");
        try {
            if(c.getResponseCode()!=200) throw new IOException("HTTP "+c.getResponseCode());
            StringBuilder text=new StringBuilder();
            try(Reader r=new InputStreamReader(c.getInputStream(),"UTF-8")) {
                char[] b=new char[4096]; int n;
                while((n=r.read(b))!=-1) { text.append(b,0,n); if(text.length()>1000000) throw new IOException("Response too large"); }
            }
            return new JSONObject(text.toString());
        } finally { c.disconnect(); }
    }
    static JSONObject weather(double lat,double lon) throws Exception {
        return get("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+
            "&current=temperature_2m,weather_code&timezone=auto");
    }
    static JSONObject prayers(double lat,double lon,String day) throws Exception {
        JSONObject response=get("https://api.aladhan.com/v1/timings/"+day+"?latitude="+lat+"&longitude="+lon+"&method=4");
        if(response.optInt("code")!=200) throw new IOException("Prayer service error");
        return response.getJSONObject("data");
    }
    static JSONArray cities(String name) throws Exception {
        JSONObject response=get("https://geocoding-api.open-meteo.com/v1/search?name="+
            URLEncoder.encode(name,"UTF-8")+"&count=8&language=ar&format=json");
        JSONArray a=response.optJSONArray("results"); return a==null?new JSONArray():a;
    }
    static String day(String zone) {
        SimpleDateFormat f=new SimpleDateFormat("dd-MM-yyyy",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone(zone)); return f.format(new Date());
    }
    static String description(int code,boolean en) {
        if(code==0) return en?"Clear":"صحو";
        if(code<=3) return en?"Cloudy":"غائم";
        if(code==45||code==48) return en?"Fog":"ضباب";
        if(code>=95) return en?"Thunderstorms":"عواصف رعدية";
        if(code>=71&&code<=77||code==85||code==86) return en?"Snow":"ثلوج";
        return en?"Rain / drizzle":"أمطار / رذاذ";
    }
}
