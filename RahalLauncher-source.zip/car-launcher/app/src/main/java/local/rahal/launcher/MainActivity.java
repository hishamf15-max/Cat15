package local.rahal.launcher;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.location.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity implements LocationListener {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private TextView clock,date,speed,weather,prayer,place,next;
    private LocationManager manager;
    private boolean english,active,busy,hasPlace;
    private String mode,zone,city;
    private double lat,lon;
    private long lastFix,lastAttempt;
    private int generation;
    private JSONObject weatherData,prayerData;
    private long weatherFetched;
    private String prayerDay="";
    private final String[] keys={"Fajr","Dhuhr","Asr","Maghrib","Isha"};
    private final String[] names={"الفجر","الظهر","العصر","المغرب","العشاء"};
    private String tr(String ar,String en){return english?en:ar;}
    private Locale locale(){return english?Locale.US:new Locale("ar","SA");}
    private final Runnable ticker=new Runnable(){public void run(){
        if(!active)return;
        updateClock(); renderData();
        if(lastFix==0||SystemClock.elapsedRealtime()-lastFix>10000)
            speed.setText(tr("— كم/س\nبانتظار إشارة GPS","— km/h\nWaiting for GPS"));
        if(hasPlace&&prefs.getBoolean("online",false)&&SystemClock.elapsedRealtime()-lastAttempt>900000) refresh(false);
        handler.postDelayed(this,1000);
    }};
    public void onCreate(Bundle state){
        super.onCreate(state); prefs=getSharedPreferences("rahal",0);
        english=prefs.getBoolean("english",false);mode=prefs.getString("mode","auto");
        zone=prefs.getString("zone",TimeZone.getDefault().getID());city=prefs.getString("city","");
        hasPlace=prefs.contains("lat");lat=Double.longBitsToDouble(prefs.getLong("lat",0));lon=Double.longBitsToDouble(prefs.getLong("lon",0));
        manager=(LocationManager)getSystemService(LOCATION_SERVICE);
        try{weatherData=new JSONObject(prefs.getString("weather","{}"));prayerData=new JSONObject(prefs.getString("prayer","{}"));}catch(Exception ignored){}
        weatherFetched=prefs.getLong("weatherFetched",0);prayerDay=prefs.getString("prayerDay","");
        build();
        if(!prefs.getBoolean("introduced",false)) handler.post(()->new AlertDialog.Builder(this)
            .setTitle("رحّال · إعداد أول مرة")
            .setMessage("لجلب الطقس ومواقيت الصلاة يرسل التطبيق إحداثيات الموقع إلى Open-Meteo وAlAdhan. يمكنك اختيار مدينة يدويًا أو منح إذن الموقع. هذه نسخة اختبار، وسرعة GPS تقريبية. حساب الصلاة الافتراضي: أم القرى.")
            .setPositiveButton("تفعيل الخدمات",(d,w)->{prefs.edit().putBoolean("online",true).putBoolean("introduced",true).apply();settings();})
            .setNegativeButton("بدون اتصال",(d,w)->prefs.edit().putBoolean("introduced",true).apply()).show());
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView text(String v,int size){
        TextView t=new TextView(this);t.setText(v);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6),dp(6),dp(6),dp(6));return t;
    }
    private LinearLayout card(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setGravity(Gravity.CENTER);b.setPadding(dp(8),dp(8),dp(8),dp(8));
        GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(22,36,52));g.setCornerRadius(dp(18));b.setBackground(g);return b;
    }
    private void weighted(LinearLayout row,View v,float weight){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.setMargins(dp(5),dp(5),dp(5),dp(5));row.addView(v,p);
    }
    private void button(LinearLayout row,String name,View.OnClickListener click){
        Button b=new Button(this);b.setText(name);b.setTextSize(16);b.setOnClickListener(click);row.addView(b,new LinearLayout.LayoutParams(0,dp(56),1));
    }
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(8,17,29));
        root.setLayoutDirection(english?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(10)+i.getSystemWindowInsetLeft(),dp(6)+i.getSystemWindowInsetTop(),dp(10)+i.getSystemWindowInsetRight(),dp(6)+i.getSystemWindowInsetBottom());return i;});
        place=text("",14);place.setTextColor(Color.rgb(99,213,196));root.addView(place);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=new LinearLayout(this);content.setOrientation(1);scroll.addView(content);
        LinearLayout main=new LinearLayout(this);content.addView(main,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout time=card();clock=text("",52);clock.setTypeface(null,Typeface.BOLD);date=text("",17);time.addView(clock);time.addView(date);weighted(main,time,1.35f);
        LinearLayout gps=card();gps.addView(text(tr("السرعة · GPS","SPEED · GPS"),16));speed=text("—",32);gps.addView(speed);weighted(main,gps,1);
        LinearLayout sky=card();weather=text(tr("الطقس\nبانتظار الموقع","Weather\nWaiting for location"),22);sky.addView(weather);sky.addView(text("Open-Meteo · CC BY 4.0",10));weighted(main,sky,1);
        LinearLayout prayers=card();prayer=text("",18);next=text("",16);next.setTextColor(Color.rgb(99,213,196));prayers.addView(prayer);prayers.addView(next);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.setMargins(dp(5),dp(8),dp(5),dp(8));content.addView(prayers,pp);
        LinearLayout actions=new LinearLayout(this);button(actions,tr("التطبيقات","Apps"),v->apps());button(actions,tr("الموقع والإعدادات","Settings"),v->settings());
        button(actions,tr("تحديث","Refresh"),v->refresh(true));button(actions,"عربي / EN",v->{english=!english;prefs.edit().putBoolean("english",english).apply();build();});
        root.addView(actions);setContentView(root);updateClock();renderData();
    }
    private String format(String pattern,long time){SimpleDateFormat f=new SimpleDateFormat(pattern,locale());f.setTimeZone(TimeZone.getTimeZone(zone));return f.format(new Date(time));}
    private void updateClock(){clock.setText(format("HH:mm",System.currentTimeMillis()));date.setText(format("EEEE\nd MMMM yyyy",System.currentTimeMillis()));}
    private void renderData(){
        place.setText("رحّال  •  "+(hasPlace?(city.isEmpty()?String.format(Locale.US,"%.3f, %.3f",lat,lon):city)+"  •  "+zone:tr("اختر الموقع من الإعدادات","Choose location in Settings")));
        try{
            JSONObject c=weatherData.getJSONObject("current");
            weather.setText(String.format(locale(),"%.0f °C",c.getDouble("temperature_2m"))+"\n"+OnlineData.description(c.getInt("weather_code"),english)+"\n"+
                tr("آخر جلب: ","Fetched: ")+format("HH:mm",weatherFetched)+(System.currentTimeMillis()-weatherFetched>3600000?tr(" · قديم"," · stale"):""));
        }catch(Exception e){weather.setText(tr("الطقس · —\nلا توجد بيانات","Weather · —\nNo data"));}
        try{
            if(!prayerDay.equals(OnlineData.day(zone)))throw new Exception();
            JSONObject timings=prayerData.getJSONObject("timings");StringBuilder line=new StringBuilder();
            Calendar now=Calendar.getInstance(TimeZone.getTimeZone(zone));int minute=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE), upcoming=-1,delta=0;
            for(int i=0;i<5;i++){
                String t=timings.getString(keys[i]).substring(0,5);if(!t.matches("[0-9]{2}:[0-9]{2}"))throw new Exception();
                line.append(english?keys[i]:names[i]).append("  ").append(t).append(i==2?"\n":i<4?"     ":"");
                int n=Integer.parseInt(t.substring(0,2))*60+Integer.parseInt(t.substring(3,5));if(upcoming<0&&n>minute){upcoming=i;delta=n-minute;}
            }
            prayer.setText(line.toString());next.setText(upcoming<0?tr("انتهت مواقيت اليوم · أم القرى","Today's prayers complete · Umm al-Qura"):
                tr("القادمة: ","Next: ")+(english?keys[upcoming]:names[upcoming])+" · "+(delta/60)+tr(" س ","h ")+(delta%60)+tr(" د","m"));
        }catch(Exception e){prayer.setText(tr("مواقيت الصلاة · لا توجد بيانات لهذا اليوم","Prayer times · No data for today"));next.setText(tr("فعّل الإنترنت وحدد الموقع · طريقة أم القرى","Enable internet and set location · Umm al-Qura"));}
    }
    private void savePlace(){prefs.edit().putLong("lat",Double.doubleToLongBits(lat)).putLong("lon",Double.doubleToLongBits(lon)).putString("city",city).putString("zone",zone).apply();}
    private void setPlace(double a,double b,String name,String tz){
        lat=a;lon=b;city=name;zone=tz;hasPlace=true;generation++;weatherData=null;prayerData=null;prayerDay="";
        prefs.edit().remove("weather").remove("prayer").remove("prayerDay").apply();savePlace();renderData();refresh(false);
    }
    private void refresh(boolean manual){
        if(!prefs.getBoolean("online",false)){if(manual)toast(tr("فعّل الخدمات من الإعدادات","Enable online services in Settings"));return;}
        if(!hasPlace){if(manual)settings();return;}if(busy)return;
        busy=true;lastAttempt=SystemClock.elapsedRealtime();int token=generation;double a=lat,b=lon;String requestZone=zone;
        worker.execute(()->{
            JSONObject w=null,p=null;String z=requestZone,day;
            try{w=OnlineData.weather(a,b);z=w.optString("timezone",requestZone);}catch(Exception ignored){}
            day=OnlineData.day(z);try{p=OnlineData.prayers(a,b,day);z=p.getJSONObject("meta").getString("timezone");
                if(!day.equals(OnlineData.day(z))){day=OnlineData.day(z);p=OnlineData.prayers(a,b,day);}
            }catch(Exception ignored){p=null;}
            final JSONObject fw=w,fp=p;final String fz=z,fd=day;
            handler.post(()->{busy=false;if(isDestroyed())return;if(token!=generation){refresh(false);return;}
                zone=fz;savePlace();SharedPreferences.Editor ed=prefs.edit();
                if(fw!=null){weatherData=fw;weatherFetched=System.currentTimeMillis();ed.putString("weather",fw.toString()).putLong("weatherFetched",weatherFetched);}
                if(fp!=null){prayerData=fp;prayerDay=fd;ed.putString("prayer",fp.toString()).putString("prayerDay",fd);}
                ed.apply();renderData();if(manual)toast(fw!=null&&fp!=null?tr("تم التحديث","Updated"):tr("تعذر تحديث بعض البيانات؛ تحقق من الاتصال","Some data could not update; check connection"));
            });
        });
    }
    private void settings(){
        String[] items={tr("تحديد تلقائي: GPS والشبكة","Automatic: GPS + network"),tr("GPS فقط","GPS only"),tr("اختيار المدينة يدويًا","Choose city manually"),
            tr("الخدمات عبر الإنترنت: ","Online services: ")+(prefs.getBoolean("online",false)?tr("مفعلة","On"):tr("متوقفة","Off")),tr("إعدادات أندرويد","Android settings")};
        new AlertDialog.Builder(this).setTitle(tr("الموقع والإعدادات","Location and settings")).setItems(items,(d,i)->{
            if(i<2){mode=i==0?"auto":"gps";prefs.edit().putString("mode",mode).apply();restartLocation();enableGps();}
            if(i==2)chooseCity();
            if(i==3){boolean enable=!prefs.getBoolean("online",false);if(enable)new AlertDialog.Builder(this).setMessage(tr("ستُرسل إحداثيات الموقع إلى Open-Meteo وAlAdhan لجلب الطقس والصلاة.","Coordinates will be sent to Open-Meteo and AlAdhan for weather and prayer times.")).setPositiveButton(tr("تفعيل","Enable"),(x,y)->{prefs.edit().putBoolean("online",true).apply();refresh(true);}).setNegativeButton(tr("إلغاء","Cancel"),null).show();
                else {prefs.edit().putBoolean("online",false).apply();generation++;toast(tr("تم إيقاف الطلبات الجديدة","New requests disabled"));}}
            if(i==4)startActivity(new Intent(Settings.ACTION_SETTINGS));
        }).show();
    }
    private void chooseCity(){
        String[] cities={"الرياض / Riyadh","جدة / Jeddah","مكة / Makkah","المدينة / Madinah","الدمام / Dammam","الطائف / Taif",tr("بحث عن مدينة أخرى","Search another city")};
        double[][] points={{24.7136,46.6753},{21.4858,39.1925},{21.4225,39.8262},{24.4672,39.6024},{26.4207,50.0888},{21.2703,40.4158}};
        new AlertDialog.Builder(this).setTitle(tr("اختر المدينة","Choose city")).setItems(cities,(d,i)->{
            if(i==6){searchCity();return;}manualPlace(points[i][0],points[i][1],cities[i],"Asia/Riyadh");
        }).show();
    }
    private void manualPlace(double a,double b,String name,String tz){mode="manual";prefs.edit().putString("mode",mode).apply();restartLocation();setPlace(a,b,name,tz);}
    private void searchCity(){
        if(!prefs.getBoolean("online",false)){toast(tr("فعّل الخدمات للبحث عن مدينة","Enable online services to search"));return;}
        EditText input=new EditText(this);input.setSingleLine();input.setHint(tr("اسم المدينة","City name"));
        new AlertDialog.Builder(this).setTitle(tr("بحث المدينة","City search")).setView(input).setPositiveButton(tr("بحث","Search"),(d,n)->{
            String q=input.getText().toString().trim();if(q.length()<2)return;toast(tr("جارٍ البحث","Searching"));
            worker.execute(()->{try{JSONArray a=OnlineData.cities(q);String[] labels=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject c=a.getJSONObject(i);labels[i]=c.getString("name")+" · "+c.optString("admin1")+" · "+c.optString("country");}
                handler.post(()->{if(isDestroyed())return;if(labels.length==0){toast(tr("لا نتائج، جرّب الاسم بالإنجليزية","No results; try the English name"));return;}
                    new AlertDialog.Builder(this).setItems(labels,(x,i)->{try{JSONObject c=a.getJSONObject(i);manualPlace(c.getDouble("latitude"),c.getDouble("longitude"),labels[i],c.getString("timezone"));}catch(Exception e){toast(tr("بيانات المدينة ناقصة","Incomplete city data"));}}).show();});
            }catch(Exception e){handler.post(()->toast(tr("تعذر البحث، تحقق من الإنترنت","Search failed; check internet")));}});
        }).setNegativeButton(tr("إلغاء","Cancel"),null).show();
    }
    private void toast(String text){if(!isDestroyed())Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    private void apps(){
        List<ResolveInfo> list=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
        Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=list.get(i).loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this).setTitle(tr("التطبيقات","Apps")).setItems(labels,(d,i)->{ResolveInfo r=list.get(i);try{startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name)));}catch(RuntimeException e){toast(tr("تعذر الفتح","Unable to open"));}}).show();
    }
    private void enableGps(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);return;}
        if(manager!=null&&!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)){startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));return;}subscribe();
    }
    private void restartLocation(){if(manager!=null)manager.removeUpdates(this);subscribe();}
    private void subscribe(){
        if(manager==null)return;boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        boolean coarse=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if(fine)try{manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,this);}catch(RuntimeException ignored){}
        if((fine||coarse)&&mode.equals("auto"))try{manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,30000,100,this);}catch(RuntimeException ignored){}
    }
    public void onLocationChanged(Location l){
        if(SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos()>30000000000L)return;
        boolean gps=LocationManager.GPS_PROVIDER.equals(l.getProvider());
        if(gps&&SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos()<=10000000000L&&l.hasSpeed()&&l.getSpeed()>=0&&l.hasAccuracy()&&l.getAccuracy()<=50){
            lastFix=SystemClock.elapsedRealtime();speed.setText(String.format(locale(),"%.0f",l.getSpeed()*3.6)+tr(" كم/س\nGPS تقريبي"," km/h\nGPS estimate"));
        }
        if(mode.equals("manual")||(!gps&&mode.equals("gps")))return;
        if(!gps&&lastFix!=0&&SystemClock.elapsedRealtime()-lastFix<10000)return;
        if(!l.hasAccuracy()||l.getAccuracy()>10000)return;
        float[] distance=new float[1];Location.distanceBetween(lat,lon,l.getLatitude(),l.getLongitude(),distance);
        if(!hasPlace||distance[0]>5000)setPlace(l.getLatitude(),l.getLongitude(),"",TimeZone.getDefault().getID());
    }
    public void onProviderDisabled(String p){if(p.equals(LocationManager.GPS_PROVIDER))lastFix=0;}
    public void onProviderEnabled(String p){}
    public void onStatusChanged(String p,int status,Bundle extras){}
    public void onRequestPermissionsResult(int r,String[] p,int[] results){super.onRequestPermissionsResult(r,p,results);if(r==10){subscribe();if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)toast(tr("السرعة تحتاج إذن الموقع الدقيق وإشارة GPS","Speed needs precise location permission and GPS"));}}
    protected void onResume(){super.onResume();active=true;handler.removeCallbacks(ticker);handler.post(ticker);subscribe();if(hasPlace&&lastAttempt==0)refresh(false);}
    protected void onPause(){super.onPause();active=false;handler.removeCallbacks(ticker);if(manager!=null)manager.removeUpdates(this);lastFix=0;}
    protected void onDestroy(){super.onDestroy();worker.shutdownNow();handler.removeCallbacksAndMessages(null);}
}
